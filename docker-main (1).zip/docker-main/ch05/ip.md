

# 🌐 ip : 리눅스 네트워킹 필수 도구

리눅스에서 네트워크 인터페이스, 라우팅, 터널 등을 관리할 때 가장 강력하게 쓰이는 도구가 바로 **`ip` 명령어**입니다.
예전에는 `ifconfig`, `route` 같은 명령어를 많이 썼지만, 이제는 거의 모든 현대 리눅스 시스템에서 `ip`가 표준이에요. 🚀

이번 글에서는 **`ip` 명령어의 기본 구조부터 실전 예시까지** 깔끔하게 정리해보겠습니다.

---

## 🧠 1. ip 명령어란?

* **패키지**: `iproute2`에 포함
* **용도**:

  * 네트워크 인터페이스 관리
  * IP 주소 할당 및 삭제
  * 라우팅 테이블 관리
  * 터널, 멀티캐스트, ARP 캐시 등 다양한 네트워킹 설정
* **특징**:

  * 모듈형 구조 → 명령어 뒤에 서브커맨드 추가 방식
  * `ifconfig`, `route`, `netstat` 명령어를 대체

---

## 🏗 2. 기본 구조

```bash
ip [옵션] <객체> <동작> [매개변수]
```

* **객체(Object)**: `link`, `addr`, `route`, `neigh`, `rule` 등
* **동작(Command)**: `show`, `add`, `del`, `set` 등
* **예시**:

  ```bash
  ip addr show
  ip link set eth0 up
  ip route add default via 192.168.0.1
  ```

---

## 🔍 3. 자주 쓰는 객체(Object)

| 객체(Object) | 설명                  | 예시                                     |
| ---------- | ------------------- | -------------------------------------- |
| `link`     | 네트워크 인터페이스 관리       | `ip link show`                         |
| `addr`     | IP 주소 관리            | `ip addr add 192.168.0.10/24 dev eth0` |
| `route`    | 라우팅 테이블 관리          | `ip route show`                        |
| `neigh`    | ARP 캐시(Neighbor) 관리 | `ip neigh show`                        |
| `rule`     | 정책 기반 라우팅 관리        | `ip rule show`                         |

---

## 🛠 4. 실전 예시 모음

### 4.1 인터페이스 상태 보기

```bash
ip link show
```

* 옛날 `ifconfig` 명령의 대체 명령
* 인터페이스 이름, MAC 주소, MTU, 상태(UP/DOWN) 확인 가능

---

### 4.2 IP 주소 보기

```bash
ip addr show
```

* `ifconfig`에서 보던 IP 주소, 브로드캐스트 주소 등을 확인
* 특정 인터페이스만 보고 싶다면:

  ```bash
  ip addr show dev eth0
  ```

---

### 4.3 IP 주소 추가 / 삭제

```bash
ip addr add 192.168.1.100/24 dev eth0
ip addr del 192.168.1.100/24 dev eth0
```

* 여러 개의 IP를 인터페이스에 할당 가능(Secondary IP)

---

### 4.4 라우팅 테이블 관리

```bash
# 기본 게이트웨이 설정
ip route add default via 192.168.1.1

# 현재 라우팅 테이블 보기
ip route show
```

---

### 4.5 인터페이스 Up/Down

```bash
ip link set eth0 up
ip link set eth0 down
```

* 서비스 재시작 없이 바로 인터페이스 상태 제어 가능

---

### 4.6 ARP 캐시 보기

```bash
ip neigh show
```

* 로컬에서 알고 있는 IP ↔ MAC 주소 매핑 정보 출력

---

## ⚡ 5. ifconfig vs ip 비교

| 기능       | ifconfig          | ip                             |
| -------- | ----------------- | ------------------------------ |
| 상태 보기    | `ifconfig`        | `ip addr show`, `ip link show` |
| IP 추가    | 불편, 인터페이스당 1개만 가능 | `ip addr add` → 여러 개 가능        |
| 라우팅 관리   | `route` 별도 명령어 필요 | `ip route` 통합 관리               |
| 멀티캐스트/터널 | 지원 제한적            | 완전 지원                          |
| 현대성      | 레거시 도구            | 표준 도구                          |

---

## 🧾 6. 치트시트 (Cheat Sheet)

| 작업          | 명령어 예시                                 |
| ----------- | -------------------------------------- |
| 인터페이스 보기    | `ip link show`                         |
| IP 주소 보기    | `ip addr show`                         |
| IP 주소 추가    | `ip addr add 192.168.0.10/24 dev eth0` |
| IP 주소 삭제    | `ip addr del 192.168.0.10/24 dev eth0` |
| 기본 게이트웨이 설정 | `ip route add default via 192.168.0.1` |
| 라우팅 테이블 보기  | `ip route show`                        |
| 인터페이스 활성화   | `ip link set eth0 up`                  |
| 인터페이스 비활성화  | `ip link set eth0 down`                |
| ARP 캐시 보기   | `ip neigh show`                        |

---

## 7. 예시
```
ip -f inet -4 -o addr
```

---

### 🧩 명령어 구성 요소 해석

```bash
ip -f inet -4 -o addr
```

| 옵션 / 인자   | 의미                                                           |
| --------- | ------------------------------------------------------------ |
| `ip`      | `iproute2` 도구 실행. 네트워크 인터페이스, 주소, 라우팅 등 제어                   |
| `-f inet` | **패밀리(Family)** 지정 → 여기서는 IPv4(=inet) 주소 패밀리만 대상으로 함         |
| `-4`      | `-f inet`과 동일하게 **IPv4 전용**을 의미. 사실 `-4` 쓰면 `-f inet`은 생략 가능 |
| `-o`      | **oneline 출력** 옵션. 각 인터페이스 정보를 한 줄에 요약해서 출력                  |
| `addr`    | `ip` 명령어의 서브커맨드 → IP 주소 관련 작업(show/add/del) 담당               |

즉, 이 명령어는 **IPv4 주소만 한 줄 요약으로 깔끔하게 보고 싶을 때** 사용합니다.

---

### 🖥 실행 예시

```bash
$ ip -f inet -4 -o addr
1: lo    inet 127.0.0.1/8 scope host lo
2: eth0  inet 192.168.0.10/24 brd 192.168.0.255 scope global eth0
```

각 필드 의미:

* **1:** 인터페이스 인덱스 번호
* **lo / eth0:** 네트워크 인터페이스 이름
* **inet:** 주소 패밀리(IPv4)
* **192.168.0.10/24:** IP 주소와 서브넷 마스크
* **brd 192.168.0.255:** 브로드캐스트 주소
* **scope global:** 주소 범위(글로벌, 로컬, 링크 등)

---

### 📊 옵션 비교

| 명령어                    | 출력 특징                           |
| ---------------------- | ------------------------------- |
| `ip addr show`         | 기본 출력, IPv4/IPv6 모두 표시, 여러 줄 출력 |
| `ip -4 addr show`      | IPv4 주소만 표시                     |
| `ip -f inet addr show` | 위와 동일, `-4` 대신 `-f inet` 사용     |
| `ip -f inet -o addr`   | IPv4 주소만, 한 줄 요약으로 출력           |

---

### 🚀 정리

* **`-f inet` vs `-4`**
  → 둘 다 IPv4 지정, `-4`가 더 간단함.
* **`-o` 옵션**
  → 스크립트 작성 시 유용, 깔끔하게 한 줄씩 출력해서 `awk`, `grep` 같은 툴과 쉽게 조합 가능.

---




## 📌 8. 마무리

`ip` 명령어는 단순한 인터페이스 관리뿐만 아니라 **라우팅, 터널, 멀티캐스트**까지 현대 네트워크 설정의 모든 것을 통합적으로 관리할 수 있는 툴입니다.

이제 더 이상 `ifconfig`, `route` 명령어를 쓸 이유가 거의 없습니다.
한두 번 익숙해지면 오히려 더 직관적이고 스크립트 작성에도 유용하죠. 😄

