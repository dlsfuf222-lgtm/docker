

# 🛠️ Supervisord: 프로세스 관리의 비밀 병기

`supervisord`는 **Python 기반의 프로세스 제어 시스템(Process Control System)** 으로, 리눅스/유닉스 환경에서 여러 개의 장기 실행 프로세스를 자동으로 관리하고 모니터링하기 위해 만들어졌습니다.
특히 **Docker**, **마이크로서비스**, **백그라운드 데몬 관리** 같은 환경에서 많이 쓰입니다.

---

## 1. Supervisord의 핵심 개념

| 특징        | 설명                                            |
| --------- | --------------------------------------------- |
| **기능**    | 여러 프로세스를 시작, 중지, 재시작, 모니터링, 자동 재시작            |
| **언어**    | Python 기반, 크로스 플랫폼 지원                         |
| **실행 방식** | 단일 마스터 프로세스(`supervisord`) + 여러 자식 프로세스       |
| **구성 파일** | `/etc/supervisord.conf` 또는 `supervisord.conf` |
| **CLI 툴** | `supervisorctl` 명령어로 프로세스 제어                  |
| **자동 복구** | 프로세스 비정상 종료 시 자동 재시작 지원                       |

---

## 2. Supervisord의 아키텍처

```text
+---------------------+
|     supervisord      |  ← Master 프로세스 (Python 기반)
+---------------------+
          |
   -----------------
   |       |       |
   v       v       v
프로세스1  프로세스2  프로세스3  ← 자식 프로세스들
```

* **supervisord**: 설정 파일을 읽고, 지정된 모든 자식 프로세스를 실행 및 관리.
* **supervisorctl**: CLI 인터페이스. 시작/중지/재시작 명령을 마스터에게 전달.
* **Web UI (옵션)**: 설정에 따라 웹 대시보드 형태로 관리 가능.

---

## 3. 기본 사용법

### 설치

```bash
# Ubuntu/Debian
sudo apt-get install supervisor

# CentOS/RHEL
sudo yum install supervisor

# Python 기반 설치
pip install supervisor
```

### 실행

```bash
# supervisord 실행 (백그라운드)
supervisord -c /etc/supervisord.conf

# 프로세스 제어
supervisorctl start myapp
supervisorctl restart myapp
supervisorctl status
```

---

## 4. 설정 파일 예시 (`supervisord.conf`)

```ini
[supervisord]
logfile=/var/log/supervisord.log
pidfile=/var/run/supervisord.pid
childlogdir=/var/log/supervisor

[program:myapp]
command=/usr/bin/python3 /opt/myapp/app.py
autostart=true
autorestart=true
stderr_logfile=/var/log/myapp.err.log
stdout_logfile=/var/log/myapp.out.log
```

### 주요 옵션

| 옵션               | 설명                        |
| ---------------- | ------------------------- |
| `command`        | 실행할 명령어                   |
| `autostart`      | supervisord 시작 시 자동 실행 여부 |
| `autorestart`    | 프로세스 죽을 시 자동 재시작 여부       |
| `stderr_logfile` | 표준 에러 로그 경로               |
| `stdout_logfile` | 표준 출력 로그 경로               |

---

## 5. Docker 환경에서 Supervisord

Docker 컨테이너 안에서 **여러 프로세스를 동시에 실행**해야 할 때 유용합니다.
예: `nginx` + `gunicorn`을 한 컨테이너에서 돌릴 경우.

```Dockerfile
FROM ubuntu:20.04
RUN apt-get update && apt-get install -y supervisor
COPY supervisord.conf /etc/supervisord.conf
CMD ["/usr/bin/supervisord", "-c", "/etc/supervisord.conf"]
```

---

## 6. Systemd와의 비교

| 기능/특징      | Supervisord    | Systemd          |
| ---------- | -------------- | ---------------- |
| 설치 용이성     | Python 기반, 가볍다 | OS에 내장 (대부분 리눅스) |
| 프로세스 관리    | 다중 프로세스 관리 강점  | 단일 서비스 단위 중심     |
| 재시작 정책     | 지원             | 지원               |
| 로깅         | 자체 로깅 지원       | journalctl 통합    |
| Docker 친화성 | 높음             | 중간 정도            |

---

## 7. 실전 활용 시나리오

* **웹 서버**: Nginx + uWSGI + Celery 조합을 한 서버에서 관리
* **백엔드 워커**: 비동기 큐(예: Celery, RQ) 작업 관리
* **Docker**: 다중 프로세스 컨테이너 관리
* **DevOps**: 재시작 자동화, 로그 관리, 장애 복구

---

## 8. 한눈에 보는 요약

| 항목       | 설명                             |
| -------- | ------------------------------ |
| 핵심 목적    | 프로세스 실행, 모니터링, 자동 재시작          |
| 구성 요소    | `supervisord`, `supervisorctl` |
| 장점       | 간단한 설정, 자동 복구, 웹 UI 지원         |
| 단점       | OS native 서비스 관리에는 Systemd 선호  |
| 주요 사용 사례 | Docker, DevOps, 백엔드 워커 관리      |

---


